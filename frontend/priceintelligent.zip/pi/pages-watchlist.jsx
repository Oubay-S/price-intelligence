// Watchlist page with interactive threshold slider
function WatchItem({ item, product, onRemove, onChangeTarget }) {
  const range = { min: Math.floor(product.cheapest * 0.5), max: Math.ceil(product.cheapest * 1.3) };
  const save = Math.max(0, item.currentPrice - item.target);
  const below = item.target < item.currentPrice;
  const pct = ((item.target - range.min) / (range.max - range.min)) * 100;
  const curPct = ((item.currentPrice - range.min) / (range.max - range.min)) * 100;

  return (
    <div className="wl-item">
      <div className="wl-thumb"><Bucket color={product.bucketColor}/></div>

      <div className="wl-info">
        <div className="ttl">{product.name}</div>
        <div className="sub">{product.brand} · {product.size} · {product.sub} · {product.storesCount} stores</div>
        <div className="tags">
          {item.alerts.includes('email') && <span className="pill"><Icon name="bell" size={10}/> Email</span>}
          {item.alerts.includes('push') && <span className="pill"><Icon name="bell" size={10}/> Push</span>}
          <span className="pill">{product.category}</span>
        </div>
      </div>

      <div className="thr-slider">
        <div className="row">
          <span>Target</span>
          <span style={{ color: 'var(--accent)' }}>${item.target.toFixed(2)}</span>
        </div>
        <div className="thr-bar">
          <div className="cur" style={{ left: curPct + '%' }} title={'Current $' + item.currentPrice.toFixed(2)}/>
          <div className="tgt" style={{ left: pct + '%' }}/>
        </div>
        <input type="range" min={range.min} max={range.max} step="0.5" value={item.target}
          onChange={e => onChangeTarget(+e.target.value)} />
        <div className="row">
          <span>${range.min}</span>
          <span style={{ color: 'var(--text-dim)' }}>Current ${item.currentPrice.toFixed(2)}</span>
          <span>${range.max}</span>
        </div>
      </div>

      <div className="wl-cta">
        <div className="save-bubble">
          {below ? `You'd save $${save.toFixed(2)}` : 'Above current'}
        </div>
        <div className="small">{below ? 'when hit' : 'raise it to current or lower'}</div>
        <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
          <button className="btn ghost sm" onClick={onRemove}><Icon name="x" size={12}/> Remove</button>
          <a className="btn primary sm" href={'#/history?id=' + product.id}><Icon name="chart" size={12}/> History</a>
        </div>
      </div>
    </div>
  );
}

function Watchlist({ nav, params }) {
  const [items, setItems] = useState(() => WATCHLIST.map(w => ({ ...w })));
  const totalPotential = items.reduce((sum, i) => sum + Math.max(0, i.currentPrice - i.target), 0);
  const below = items.filter(i => i.target < i.currentPrice).length;

  // If ?add=<id>, add it (demo)
  useEffect(() => {
    if (params.add && !items.find(i => i.productId === params.add)) {
      const p = PRODUCTS.find(x => x.id === params.add);
      if (p) {
        setItems(prev => [{
          productId: p.id, currentPrice: p.cheapest, target: +(p.cheapest * 0.88).toFixed(2), alerts: ['email']
        }, ...prev]);
      }
    }
  }, [params.add]);

  return (
    <div className="page fade-up">
      <div className="container wl-layout">
        <div className="wl-head">
          <div>
            <h1 className="serif" style={{ margin: 0, fontSize: 44, letterSpacing: '-0.02em', fontWeight: 400 }}>Watchlist</h1>
            <p style={{ color: 'var(--text-dim)', margin: '8px 0 0' }}>Set a target price. Get alerted the second any tracked store drops below it.</p>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <a className="btn ghost" href="#/catalogue"><Icon name="plus" size={14}/> Add product</a>
            <button className="btn primary"><Icon name="bell" size={14}/> Notification settings</button>
          </div>
        </div>

        <div className="card elev" style={{ padding: 20, marginBottom: 22, display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 0 }}>
          <div style={{ borderRight: '1px solid var(--line)', paddingRight: 20 }}>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text-dim)', letterSpacing: '.08em', textTransform: 'uppercase' }}>Tracking</div>
            <div className="serif" style={{ fontSize: 34, letterSpacing: '-0.02em' }}>{items.length} <span style={{ color: 'var(--text-faint)', fontSize: 16 }}>products</span></div>
          </div>
          <div style={{ borderRight: '1px solid var(--line)', padding: '0 20px' }}>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text-dim)', letterSpacing: '.08em', textTransform: 'uppercase' }}>Potential savings</div>
            <div className="serif" style={{ fontSize: 34, letterSpacing: '-0.02em', color: 'var(--accent)' }}>${totalPotential.toFixed(2)}</div>
          </div>
          <div style={{ borderRight: '1px solid var(--line)', padding: '0 20px' }}>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text-dim)', letterSpacing: '.08em', textTransform: 'uppercase' }}>Within reach</div>
            <div className="serif" style={{ fontSize: 34, letterSpacing: '-0.02em' }}>{below}<span style={{ color: 'var(--text-faint)', fontSize: 16 }}>/{items.length}</span></div>
          </div>
          <div style={{ padding: '0 20px' }}>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text-dim)', letterSpacing: '.08em', textTransform: 'uppercase' }}>Alerts sent (30d)</div>
            <div className="serif" style={{ fontSize: 34, letterSpacing: '-0.02em' }}>14</div>
          </div>
        </div>

        <div className="wl-list">
          {items.length === 0 ? (
            <div className="card" style={{ padding: 60, textAlign: 'center', color: 'var(--text-dim)' }}>
              <div style={{ fontSize: 18, marginBottom: 6 }}>Your watchlist is empty.</div>
              <a className="btn primary" href="#/catalogue" style={{ marginTop: 12 }}>Browse catalogue <Icon name="arrow-r" size={14}/></a>
            </div>
          ) : items.map((it, i) => {
            const product = PRODUCTS.find(p => p.id === it.productId);
            if (!product) return null;
            return <WatchItem key={it.productId} item={it} product={product}
              onRemove={() => setItems(prev => prev.filter(x => x.productId !== it.productId))}
              onChangeTarget={(v) => setItems(prev => prev.map(x => x.productId === it.productId ? { ...x, target: v } : x))}/>;
          })}
        </div>
      </div>
    </div>
  );
}
window.Watchlist = Watchlist;
