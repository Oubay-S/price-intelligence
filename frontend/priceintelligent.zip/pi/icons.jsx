// Minimal stroke icons
const Icon = ({ name, size = 16, stroke = 1.5, ...rest }) => {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round', ...rest };
  switch (name) {
    case 'search':  return <svg {...common}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>;
    case 'bell':    return <svg {...common}><path d="M6 8a6 6 0 1 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>;
    case 'user':    return <svg {...common}><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/></svg>;
    case 'heart':   return <svg {...common}><path d="M12 20s-7-4.5-9.5-9.5C.5 5.5 5 2.5 8 4.5 10 5.8 12 8 12 8s2-2.2 4-3.5c3-2 7.5 1 5.5 6-2.5 5-9.5 9.5-9.5 9.5Z"/></svg>;
    case 'heart-f': return <svg {...common} fill="currentColor"><path d="M12 20s-7-4.5-9.5-9.5C.5 5.5 5 2.5 8 4.5 10 5.8 12 8 12 8s2-2.2 4-3.5c3-2 7.5 1 5.5 6-2.5 5-9.5 9.5-9.5 9.5Z"/></svg>;
    case 'chart':   return <svg {...common}><path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 6-8"/></svg>;
    case 'compare': return <svg {...common}><path d="M4 6h16M4 6l3-3M4 6l3 3"/><path d="M20 18H4m16 0-3-3m3 3-3 3"/></svg>;
    case 'grid':    return <svg {...common}><rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/></svg>;
    case 'arrow-r': return <svg {...common}><path d="M5 12h14m0 0-5-5m5 5-5 5"/></svg>;
    case 'arrow-down': return <svg {...common}><path d="M12 5v14m0 0-5-5m5 5 5-5"/></svg>;
    case 'arrow-up':   return <svg {...common}><path d="M12 19V5m0 0-5 5m5-5 5 5"/></svg>;
    case 'check':   return <svg {...common}><path d="m5 12 5 5 9-10"/></svg>;
    case 'x':       return <svg {...common}><path d="M6 6l12 12M18 6 6 18"/></svg>;
    case 'filter':  return <svg {...common}><path d="M4 5h16M7 12h10M10 19h4"/></svg>;
    case 'sort':    return <svg {...common}><path d="M8 4v16m0 0-3-3m3 3 3-3M16 20V4m0 0-3 3m3-3 3 3"/></svg>;
    case 'settings':return <svg {...common}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></svg>;
    case 'tag':     return <svg {...common}><path d="M3 12V3h9l9 9-9 9-9-9Z"/><circle cx="7.5" cy="7.5" r="1.2" fill="currentColor"/></svg>;
    case 'zap':     return <svg {...common}><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/></svg>;
    case 'globe':   return <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a13 13 0 0 1 0 18M12 3a13 13 0 0 0 0 18"/></svg>;
    case 'shield':  return <svg {...common}><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z"/></svg>;
    case 'plus':    return <svg {...common}><path d="M12 5v14M5 12h14"/></svg>;
    case 'minus':   return <svg {...common}><path d="M5 12h14"/></svg>;
    case 'google':  return <svg viewBox="0 0 48 48" width={size} height={size}><path fill="#EA4335" d="M24 9.5c3.3 0 6.3 1.1 8.7 3.3l6.5-6.5C35.1 2.3 29.9 0 24 0 14.8 0 6.9 5.3 3 13l7.6 5.9C12.5 13 17.8 9.5 24 9.5Z"/><path fill="#4285F4" d="M46.5 24.5c0-1.5-.1-3-.4-4.5H24v9h12.7c-.6 3-2.4 5.6-5 7.3l7.7 6c4.5-4.2 7.1-10.4 7.1-17.8Z"/><path fill="#FBBC05" d="M10.6 28.9c-.5-1.4-.8-2.9-.8-4.4s.3-3 .8-4.4L3 14c-1.6 3.2-2.5 6.8-2.5 10.5s.9 7.3 2.5 10.5l7.6-6.1Z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.7-6c-2.1 1.4-4.8 2.3-8.2 2.3-6.2 0-11.5-3.5-13.4-9L3 35.5C6.9 42.7 14.8 48 24 48Z"/></svg>;
    case 'github':  return <svg viewBox="0 0 24 24" width={size} height={size} fill="currentColor"><path d="M12 .3a12 12 0 0 0-3.8 23.4c.6.1.8-.3.8-.6v-2.2c-3.3.7-4-1.4-4-1.4-.6-1.4-1.4-1.8-1.4-1.8-1.1-.8.1-.8.1-.8 1.3.1 1.9 1.3 1.9 1.3 1.1 1.9 3 1.4 3.7 1 .1-.8.4-1.4.8-1.7-2.7-.3-5.5-1.3-5.5-5.9 0-1.3.5-2.3 1.3-3.2-.1-.3-.6-1.6.1-3.3 0 0 1-.3 3.3 1.2a11.4 11.4 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.7 1.7.2 3 .1 3.3.8.9 1.3 1.9 1.3 3.2 0 4.6-2.8 5.6-5.5 5.9.4.4.8 1.1.8 2.2v3.3c0 .3.2.7.8.6A12 12 0 0 0 12 .3Z"/></svg>;
    default: return null;
  }
};
window.Icon = Icon;
