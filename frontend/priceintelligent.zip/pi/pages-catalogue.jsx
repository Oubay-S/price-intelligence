// Catalogue page: category tree, search, filters, sort, product grid
function FilterBlock({ title, children }) {
  return <div className="filter-block"><h5>{title}</h5>{children}</div>;
}

function Checkbox({ label, count, checked, onChange }) {
  return (
    <label className="check">
      <input type="checkbox" checked={checked} onChange={onChange}/>
      <span>{label}</span>
      {count != null && <span className="count">{count}</span>}
    </label>
  );
}

function PriceRange({ min, max, value, onChange }) {
  return (
    <div>
      <div className="mono" style={{ fontSize: 12, color: 'var(--text-dim)', display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <span>${value[0]}</span><span>${value[1]}+</span>
      </div>
      <div style={{ position: 'relative', height: 4, background: 'var(--bg-3)', borderRadius: 2 }}>
        <div style={{ position: 'absolute', left: (value[0]-min)/(max-min)*100 + '%', right: (max-value[1])/(max-min)*100 + '%', top: 0, bottom: 0, background: 'var(--accent)', borderRadius: 2 }}/>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
        <input type="number" className="input" value={value[0]} onChange={e => onChange([+e.target.value, value[1]])} style={{ width: '50%', padding: 7, fontSize: 13 }}/>
        <input type="number" className="input" value={value[1]} onChange={e => onChange([value[0], +e.target.value])} style={{ width: '50%', padding: 7, fontSize: 13 }}/>
      </div>
    </div>
  );
}

function CategoryTree({ activeCat, activeSub, onPick }) {
  const [open, setOpen] = useState(() => new Set(TAXONOMY.map(t => t.id)));
  const toggleOpen = (id) => {
    setOpen(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };
  return (
    <div className="cat-tree">
      <button className={'cat-tree-all ' + (!activeCat ? 'active' : '')} onClick={() => onPick(null, null)}>
        <Icon name="grid" size={13}/> All products
        <span className="count">{PRODUCTS.length}</span>
      </button>
      {TAXONOMY.map(top => {
        const isOpen = open.has(top.id);
        const topCount = PRODUCTS.filter(p => p.categoryId === top.id).length;
        const isActiveTop = activeCat === top.id && !activeSub;
        return (
          <div key={top.id} className="cat-tree-group">
            <button className={'cat-tree-top ' + (isActiveTop ? 'active' : '')} onClick={() => onPick(top.id, null)}>
              <span className="caret" onClick={(e) => { e.stopPropagation(); toggleOpen(top.id); }}>
                <Icon name="arrow-r" size={10} style={{ transform: isOpen ? 'rotate(90deg)' : 'none', transition: 'transform .15s' }}/>
              </span>
              <span>{top.name}</span>
              <span className="count">{topCount}</span>
            </button>
            {isOpen && (
              <div className="cat-tree-subs">
                {top.subs.map(sub => {
                  const n = PRODUCTS.filter(p => p.subId === sub.id).length;
                  const active = activeSub === sub.id;
                  return (
                    <button key={sub.id} className={'cat-tree-sub ' + (active ? 'active' : '')} onClick={() => onPick(top.id, sub.id)}>
                      <span>{sub.name}</span>
                      <span className="count">{n}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function ProductCard({ p, onClick, onWatchlist }) {
  return (
    <div className="prod" onClick={onClick} data-price={'$' + p.cheapest.toFixed(2)}>
      <div className="prod-img">
        <Bucket color={p.bucketColor}/>
        <div className="lbl"><span>{p.size}</span><span>{p.sub}</span></div>
        {p.savePct >= 15 && (
          <span className="pill accent" style={{ position: 'absolute', top: 10, left: 10, fontSize: 10, padding: '2px 8px' }}>
            −{p.savePct}% off RRP
          </span>
        )}
      </div>
      <div className="prod-body">
        <span className="prod-brand">{p.brand}</span>
        <span className="prod-name">{p.name.replace(p.brand, '').trim()}</span>
        <div className="prod-meta">
          <span>★ {p.rating}</span>
          <span style={{ color: 'var(--text-faint)' }}>·</span>
          <span>{p.reviews.toLocaleString()} reviews</span>
        </div>
      </div>
      <div className="prod-foot">
        <div className="prod-price">
          <span className="cur">${p.cheapest.toFixed(2)}</span>
          <span className="was">${p.rrp.toFixed(2)}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className="prod-stores">{p.storesCount} stores</span>
          <button className="iconbtn" onClick={(e) => { e.stopPropagation(); onWatchlist(); }} title="Add to watchlist">
            <Icon name="heart" size={14}/>
          </button>
        </div>
      </div>
    </div>
  );
}

function Catalogue({ nav }) {
  const [q, setQ] = useState('');
  const [activeCat, setActiveCat] = useState(null);   // top-level category id
  const [activeSub, setActiveSub] = useState(null);   // sub id
  const [brands, setBrands] = useState(new Set());
  const [priceR, setPriceR] = useState([0, 1200]);
  const [sort, setSort] = useState('price-asc');
  const [stores, setStores] = useState(new Set());
  const [inStockOnly, setInStockOnly] = useState(true);
  const [onSaleOnly, setOnSaleOnly] = useState(false);

  const toggle = (set, key, update) => {
    const n = new Set(set); n.has(key) ? n.delete(key) : n.add(key); update(n);
  };

  const filtered = useMemo(() => {
    let list = PRODUCTS.filter(p => {
      if (q && !(p.name.toLowerCase().includes(q.toLowerCase()) || p.brand.toLowerCase().includes(q.toLowerCase()) || p.sub.toLowerCase().includes(q.toLowerCase()))) return false;
      if (activeCat && p.categoryId !== activeCat) return false;
      if (activeSub && p.subId !== activeSub) return false;
      if (brands.size && !brands.has(p.brand)) return false;
      if (p.cheapest < priceR[0] || p.cheapest > priceR[1]) return false;
      if (onSaleOnly && p.savePct < 10) return false;
      return true;
    });
    const cmp = {
      'price-asc':  (a, b) => a.cheapest - b.cheapest,
      'price-desc': (a, b) => b.cheapest - a.cheapest,
      'rating':     (a, b) => b.rating - a.rating,
      'save':       (a, b) => b.savePct - a.savePct,
      'popular':    (a, b) => b.reviews - a.reviews,
    }[sort];
    return [...list].sort(cmp);
  }, [q, activeCat, activeSub, brands, priceR, sort, onSaleOnly]);

  // Brand list filtered by active category
  const visibleBrands = useMemo(() => {
    const scope = PRODUCTS.filter(p => (!activeCat || p.categoryId === activeCat) && (!activeSub || p.subId === activeSub));
    const counts = {};
    scope.forEach(p => { counts[p.brand] = (counts[p.brand] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([b, n]) => ({ b, n }));
  }, [activeCat, activeSub]);

  const topCatName = activeCat ? TAXONOMY.find(t => t.id === activeCat)?.name : null;
  const subName = activeSub ? SUBS.find(s => s.id === activeSub)?.name : null;
  const heading = subName || topCatName || 'Sports catalogue';

  const activeChips = [
    topCatName && !subName && { type: 'cat', label: topCatName },
    subName && { type: 'sub', label: subName },
    ...[...brands].map(b => ({ type: 'brand', label: b })),
    onSaleOnly && { type: 'sale', label: 'On sale' },
  ].filter(Boolean);

  return (
    <div className="page fade-up">
      <div className="container cat-layout">
        <aside className="cat-filters card">
          <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 500 }}><Icon name="grid" size={14}/> Categories</div>
            {(activeCat || activeSub) && <button className="btn quiet sm" onClick={() => { setActiveCat(null); setActiveSub(null); }}>Clear</button>}
          </div>
          <div style={{ padding: '10px 8px' }}>
            <CategoryTree activeCat={activeCat} activeSub={activeSub} onPick={(c, s) => { setActiveCat(c); setActiveSub(s); }}/>
          </div>
          <FilterBlock title="Price range">
            <PriceRange min={0} max={1200} value={priceR} onChange={setPriceR}/>
          </FilterBlock>
          <FilterBlock title="Brand">
            {visibleBrands.map(({ b, n }) => (
              <Checkbox key={b} label={b} count={n} checked={brands.has(b)} onChange={() => toggle(brands, b, setBrands)}/>
            ))}
          </FilterBlock>
          <FilterBlock title="Store">
            {STORES.slice(0, 6).map(s => (
              <Checkbox key={s.id} label={s.name} checked={stores.has(s.id)} onChange={() => toggle(stores, s.id, setStores)}/>
            ))}
          </FilterBlock>
          <FilterBlock title="Availability">
            <Checkbox label="In stock only" checked={inStockOnly} onChange={() => setInStockOnly(v => !v)}/>
            <Checkbox label="On sale (−10%+)" checked={onSaleOnly} onChange={() => setOnSaleOnly(v => !v)}/>
          </FilterBlock>
        </aside>

        <div>
          <div style={{ marginBottom: 22 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
              <div>
                {(topCatName || subName) && (
                  <div className="mono" style={{ fontSize: 11, color: 'var(--text-faint)', letterSpacing: '.1em', textTransform: 'uppercase', marginBottom: 6 }}>
                    {topCatName}{subName && <> <span style={{ color: 'var(--text-dim)' }}>/</span> <span style={{ color: 'var(--accent)' }}>{subName}</span></>}
                  </div>
                )}
                <h1 className="serif" style={{ margin: 0, fontSize: 44, letterSpacing: '-0.02em', fontWeight: 400 }}>{heading}</h1>
              </div>
              <span className="mono" style={{ color: 'var(--text-dim)', fontSize: 12 }}>{filtered.length} of {PRODUCTS.length} products</span>
            </div>
            <p style={{ color: 'var(--text-dim)', margin: '8px 0 0' }}>Lowest live prices from {STORES.length} tracked stores. Refreshed every 15 minutes.</p>
          </div>

          <div className="cat-toolbar">
            <div className="search" style={{ flex: 1 }}>
              <Icon name="search" size={15}/>
              <input className="input" placeholder="Search shoes, watches, gloves, balls…" value={q} onChange={e => setQ(e.target.value)}/>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Icon name="sort" size={14} />
              <select className="select" value={sort} onChange={e => setSort(e.target.value)} style={{ width: 180 }}>
                <option value="price-asc">Lowest price</option>
                <option value="price-desc">Highest price</option>
                <option value="save">Biggest discount</option>
                <option value="rating">Highest rated</option>
                <option value="popular">Most popular</option>
              </select>
            </div>
          </div>

          {activeChips.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 14 }}>
              {activeChips.map((c, i) => (
                <span key={i} className="pill">
                  {c.label} <button className="btn quiet sm" style={{ padding: 0, marginLeft: 2 }} onClick={() => {
                    if (c.type === 'cat') setActiveCat(null);
                    if (c.type === 'sub') setActiveSub(null);
                    if (c.type === 'brand') { const n = new Set(brands); n.delete(c.label); setBrands(n); }
                    if (c.type === 'sale') setOnSaleOnly(false);
                  }}><Icon name="x" size={12}/></button>
                </span>
              ))}
            </div>
          )}

          {filtered.length === 0 ? (
            <div className="card" style={{ padding: 60, textAlign: 'center', color: 'var(--text-dim)' }}>
              <div style={{ fontSize: 18, marginBottom: 6 }}>No products match.</div>
              <div style={{ fontSize: 13 }}>Try widening your price range or clearing filters.</div>
            </div>
          ) : (
            <div className="cat-grid">
              {filtered.map(p => (
                <ProductCard key={p.id} p={p}
                  onClick={() => nav('/history?id=' + p.id)}
                  onWatchlist={() => { alert('Added ' + p.name + ' to watchlist'); nav('/watchlist'); }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
window.Catalogue = Catalogue;
