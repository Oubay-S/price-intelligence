// App root
const { useEffect: UE, useState: US } = React;

function App() {
  const route = useHashRoute();
  const [tweaks, setTweaks] = useTweaks();
  const [editMode, setEditMode] = useEditMode();
  const [tweaksOpen, setTweaksOpen] = US(false);

  UE(() => { if (editMode) setTweaksOpen(true); }, [editMode]);

  const path = route.path || '/';

  let Page;
  if (path === '/' || path === '') Page = <Landing nav={route.nav}/>;
  else if (path === '/signup') Page = <SignUp nav={route.nav}/>;
  else if (path === '/signin') Page = <SignIn nav={route.nav}/>;
  else if (path === '/catalogue') Page = <Catalogue nav={route.nav}/>;
  else if (path === '/history') Page = <PriceHistory nav={route.nav} params={route.params}/>;
  else if (path === '/compare') Page = <ComparePrices nav={route.nav} params={route.params}/>;
  else if (path === '/watchlist') Page = <Watchlist nav={route.nav} params={route.params}/>;
  else Page = <Landing nav={route.nav}/>;

  const hideSearch = path === '/signup' || path === '/signin';

  return (
    <div className="app" data-screen-label={path}>
      <Header route={route} nav={route.nav}/>
      {!hideSearch && <GlobalSearch nav={route.nav}/>}
      {Page}
      <Footer/>
      {editMode && tweaksOpen && <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} onClose={() => setTweaksOpen(false)}/>}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
