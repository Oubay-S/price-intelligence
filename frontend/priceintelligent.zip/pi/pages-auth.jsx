// Sign up / Sign in pages
function AuthShowcase() {
  // Fake animated product price ticking down
  const [price, setPrice] = useState(58.99);
  useEffect(() => {
    const id = setInterval(() => {
      setPrice(p => Math.max(42.80, +(p - 0.3 - Math.random() * 0.4).toFixed(2)));
    }, 900);
    return () => clearInterval(id);
  }, []);
  return (
    <div style={{ width: '100%', maxWidth: 440 }}>
      <div className="card" style={{ padding: 20, borderRadius: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <div style={{ width: 48, height: 48, borderRadius: 10, background: 'var(--bg-2)', display: 'grid', placeItems: 'center' }}>
            <Bucket color="#2a3a1f" className="" />
          </div>
          <div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text-faint)', letterSpacing: '.1em', textTransform: 'uppercase' }}>Pacer</div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>Carbon Plate Racer · US 10</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <span className="serif" style={{ fontSize: 54, letterSpacing: '-0.02em', lineHeight: 1 }}>${price.toFixed(2)}</span>
          <span className="pill success" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Icon name="arrow-down" size={10}/> -27%
          </span>
        </div>
        <div style={{ marginTop: 10, fontSize: 12, color: 'var(--text-dim)' }}>at PeakMart — lowest in 90 days</div>
        <hr className="sep" style={{ margin: '16px 0' }}/>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text-dim)' }}>
          <span>Target price</span>
          <span className="mono" style={{ color: 'var(--accent)' }}>$45.00</span>
        </div>
        <div className="thr-bar" style={{ margin: '10px 0 4px' }}>
          <div className="cur" style={{ left: '72%' }}/>
          <div className="tgt" style={{ left: '58%' }}/>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-faint)', fontFamily: 'JetBrains Mono, monospace' }}>
          <span>$30</span><span>$70</span>
        </div>
      </div>
      <div style={{ marginTop: 18, display: 'flex', alignItems: 'center', gap: 10, color: 'var(--text-dim)', fontSize: 13 }}>
        <Icon name="bell" size={14}/> Alert triggered when any store drops below target
      </div>
    </div>
  );
}

function AuthField({ label, type = 'text', placeholder, value, onChange, right }) {
  return (
    <div className="field">
      <label>{label}</label>
      <div style={{ position: 'relative' }}>
        <input className="input" type={type} placeholder={placeholder} value={value} onChange={onChange}/>
        {right && <div style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)' }}>{right}</div>}
      </div>
    </div>
  );
}

function SignUp({ nav }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const submit = (e) => { e.preventDefault(); nav('/catalogue'); };
  return (
    <div className="page fade-up">
      <div className="auth-wrap">
        <div className="auth-left">
          <form className="auth-form" onSubmit={submit}>
            <h2>Create your account.</h2>
            <p className="sub">Free forever. Cancel anytime. No store logins needed.</p>
            <div className="oauth-row">
              <button type="button" className="btn ghost" style={{ justifyContent: 'center' }}><Icon name="google" size={16}/> Google</button>
              <button type="button" className="btn ghost" style={{ justifyContent: 'center' }}><Icon name="github" size={16}/> GitHub</button>
            </div>
            <div className="divider">or continue with email</div>
            <AuthField label="Full name" placeholder="Alex Morgan" value={name} onChange={e => setName(e.target.value)}/>
            <AuthField label="Email" type="email" placeholder="you@sports.com" value={email} onChange={e => setEmail(e.target.value)}/>
            <AuthField label="Password" type="password" placeholder="At least 8 characters" value={password} onChange={e => setPassword(e.target.value)}/>
            <label className="check" style={{ margin: '8px 0 18px' }}>
              <input type="checkbox" defaultChecked/> Email me when tracked prices drop
            </label>
            <button className="btn primary lg" style={{ width: '100%', justifyContent: 'center' }}>Create account <Icon name="arrow-r" size={16}/></button>
            <p style={{ marginTop: 18, color: 'var(--text-dim)', fontSize: 13, textAlign: 'center' }}>
              Already have an account? <a href="#/signin" style={{ color: 'var(--accent)' }}>Sign in</a>
            </p>
          </form>
        </div>
        <div className="auth-right">
          <div className="auth-right-inner"><AuthShowcase/></div>
        </div>
      </div>
    </div>
  );
}

function SignIn({ nav }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const submit = (e) => { e.preventDefault(); nav('/catalogue'); };
  return (
    <div className="page fade-up">
      <div className="auth-wrap">
        <div className="auth-left">
          <form className="auth-form" onSubmit={submit}>
            <h2>Welcome back.</h2>
            <p className="sub">Sign in to pick up where you left off.</p>
            <div className="oauth-row">
              <button type="button" className="btn ghost" style={{ justifyContent: 'center' }}><Icon name="google" size={16}/> Google</button>
              <button type="button" className="btn ghost" style={{ justifyContent: 'center' }}><Icon name="github" size={16}/> GitHub</button>
            </div>
            <div className="divider">or continue with email</div>
            <AuthField label="Email" type="email" placeholder="you@sports.com" value={email} onChange={e => setEmail(e.target.value)}/>
            <AuthField label="Password" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)}
              right={<a href="#/" style={{ fontSize: 12, color: 'var(--text-dim)' }}>Forgot?</a>}/>
            <label className="check" style={{ margin: '8px 0 18px' }}>
              <input type="checkbox"/> Keep me signed in for 30 days
            </label>
            <button className="btn primary lg" style={{ width: '100%', justifyContent: 'center' }}>Sign in <Icon name="arrow-r" size={16}/></button>
            <p style={{ marginTop: 18, color: 'var(--text-dim)', fontSize: 13, textAlign: 'center' }}>
              Don't have an account? <a href="#/signup" style={{ color: 'var(--accent)' }}>Create one</a>
            </p>
          </form>
        </div>
        <div className="auth-right">
          <div className="auth-right-inner"><AuthShowcase/></div>
        </div>
      </div>
    </div>
  );
}

window.SignUp = SignUp;
window.SignIn = SignIn;
