// Compare prices page
function StoreLogo({ store }) {
  const s = STORES.find(x => x.id === store) || STORES[0];
  return <div className="store-logo" style={{ background: s.color }}>{s.short}</div>;
}

function ComparePrices({ nav, params }) {
  const product = PRODUCTS.find(p => p.id === params.id) || PRODUCTS[0];
  const [q, setQ] = useState(product.name);
  const [showSearch, setShowSearch] = useState(false);

  const priced = [...product.prices].sort((a, b) => (a.price + a.shipping) - (b.price + b.shipping));
  const best = priced[0];
  const suggestions = PRODUCTS.filter(p => p.name.toLowerCase().includes(q.toLowerCase())).slice(0, 6);

  return (
    <div className="page fade-up">
      <div className="container cmp-layout">
        {/* Search */}
        <div className="search" style={{ marginBottom: 22, position: 'relative' }}>
          <Icon name="search" size={16}/>
          <input className="input" value={q} onFocus={() => setShowSearch(true)} onBlur={() => setTimeout(() => setShowSearch(false), 150)} onChange={e => { setQ(e.target.value); setShowSearch(true); }}
            placeholder="Search a product to compare prices…"/>
          {showSearch && suggestions.length > 0 && (
            <div className="card" style={{ position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0, zIndex: 10, padding: 6 }}>
              {suggestions.map(s => (
                <button key={s.id} className="btn quiet" style={{ width: '100%', justifyContent: 'flex-start', padding: '8px 10px' }}
                  onMouseDown={() => { nav('/compare?id=' + s.id); setQ(s.name); setShowSearch(false); }}>
                  <span>{s.name}</span>
                  <span style={{ marginLeft: 'auto', color: 'var(--accent)', fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>${s.cheapest.toFixed(2)}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="cmp-hero">
          <div className="cmp-img">
            <Bucket color={product.bucketColor}/>
          </div>
          <div className="cmp-info">
            <div className="brand">{product.brand} · {product.size} · {product.sub}</div>
            <h1 className="title">{product.name.replace(product.brand, '').trim()}</h1>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 6 }}>
              <span className="pill">★ {product.rating} · {product.reviews.toLocaleString()} reviews</span>
              <span className="pill">{product.category}</span>
            </div>
            <p className="desc">Compare live prices across {product.storesCount} stores. Shipping, availability and delivery window all normalized.</p>
            <div className="cmp-best">
              <Icon name="zap" size={14}/>
              Best deal: <b style={{ color: 'var(--text)', fontWeight: 500 }}>${(best.price + best.shipping).toFixed(2)}</b> at {STORES.find(s => s.id === best.store).name}
              <span style={{ color: 'var(--text-dim)' }}>· save ${(priced[priced.length - 1].price + priced[priced.length - 1].shipping - best.price - best.shipping).toFixed(2)} vs highest</span>
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
              <a className="btn primary" href={'#/history?id=' + product.id}><Icon name="chart" size={14}/> See price history</a>
              <a className="btn ghost" href={'#/watchlist?add=' + product.id}><Icon name="heart" size={14}/> Track this product</a>
            </div>
          </div>
        </div>

        <div className="card">
          <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--line)' }}>
            <div>
              <div style={{ fontWeight: 500 }}>Live prices from {priced.length} stores</div>
              <div style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 3 }}>Sorted by total cost (price + shipping)</div>
            </div>
            <span className="mono" style={{ fontSize: 11, color: 'var(--text-faint)' }}>Last scraped: 2 minutes ago</span>
          </div>
          <div className="scroll-x">
            <table className="cmp-table">
              <thead>
                <tr>
                  <th style={{ width: '28%' }}>Store</th>
                  <th>Price</th>
                  <th>Shipping</th>
                  <th>Total</th>
                  <th>Stock</th>
                  <th>Delivery</th>
                  <th>Rating</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {priced.map((row, i) => {
                  const s = STORES.find(x => x.id === row.store);
                  const total = row.price + row.shipping;
                  return (
                    <tr key={row.store} className={i === 0 ? 'best' : ''}>
                      <td>
                        <div className="store">
                          <StoreLogo store={row.store}/>
                          <div>
                            <div>{s.name}</div>
                            <div style={{ fontSize: 11, color: 'var(--text-faint)' }}>{s.name.toLowerCase().replace(/\s/g, '')}.com</div>
                          </div>
                          {i === 0 && <span className="pill accent" style={{ marginLeft: 6 }}><Icon name="zap" size={10}/> Best</span>}
                        </div>
                      </td>
                      <td><span className="cmp-price">${row.price.toFixed(2)}</span></td>
                      <td style={{ color: row.shipping === 0 ? 'var(--success)' : 'var(--text-dim)' }} className="mono">
                        {row.shipping === 0 ? 'Free' : '$' + row.shipping.toFixed(2)}
                      </td>
                      <td className="mono" style={{ fontWeight: 500 }}>${total.toFixed(2)}</td>
                      <td>
                        {row.stock
                          ? <span className="pill success"><span className="dot"/> In stock</span>
                          : <span className="pill danger"><span className="dot"/> Out of stock</span>}
                      </td>
                      <td style={{ color: 'var(--text-dim)' }}>{row.delivery}</td>
                      <td className="mono" style={{ color: 'var(--text-dim)' }}>★ {row.rating}</td>
                      <td>
                        <button className="btn ghost sm">Visit <Icon name="arrow-r" size={12}/></button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
window.ComparePrices = ComparePrices;
