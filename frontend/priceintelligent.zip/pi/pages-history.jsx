// Price history page
function PriceChart({ data, variant = 'gradient', height = 360 }) {
  const [hover, setHover] = useState(null);
  const wrapRef = useRef(null);
  const W = 900, H = height, PAD = { l: 44, r: 16, t: 20, b: 32 };
  const min = Math.min(...data);
  const max = Math.max(...data);
  const pad = (max - min) * 0.15;
  const yMin = Math.max(0, min - pad), yMax = max + pad;
  const toX = (i) => PAD.l + (i / (data.length - 1)) * (W - PAD.l - PAD.r);
  const toY = (v) => PAD.t + (1 - (v - yMin) / (yMax - yMin)) * (H - PAD.t - PAD.b);

  let path;
  if (variant === 'stepped') {
    path = data.map((v, i) => {
      const x = toX(i), y = toY(v);
      if (i === 0) return `M ${x} ${y}`;
      const prevY = toY(data[i - 1]);
      return `L ${x} ${prevY} L ${x} ${y}`;
    }).join(' ');
  } else {
    path = data.map((v, i) => (i ? 'L' : 'M') + toX(i).toFixed(1) + ' ' + toY(v).toFixed(1)).join(' ');
  }
  const area = path + ` L ${toX(data.length - 1)} ${H - PAD.b} L ${toX(0)} ${H - PAD.b} Z`;

  const yTicks = 4;
  const ticks = Array.from({ length: yTicks + 1 }, (_, i) => yMin + (yMax - yMin) * (i / yTicks));

  const onMove = (e) => {
    const rect = wrapRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const xPct = (x / rect.width) * W;
    const idx = Math.round((xPct - PAD.l) / (W - PAD.l - PAD.r) * (data.length - 1));
    if (idx >= 0 && idx < data.length) setHover(idx);
  };

  const latest = data[data.length - 1];
  const first = data[0];
  const delta = latest - first;
  const deltaPct = (delta / first) * 100;

  return (
    <div ref={wrapRef} onMouseMove={onMove} onMouseLeave={() => setHover(null)} style={{ position: 'relative' }}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: 'block', overflow: 'visible' }}>
        <defs>
          <linearGradient id="pch" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.35"/>
            <stop offset="100%" stopColor="var(--accent)" stopOpacity="0"/>
          </linearGradient>
        </defs>
        {ticks.map((t, i) => (
          <g key={i}>
            <line x1={PAD.l} x2={W - PAD.r} y1={toY(t)} y2={toY(t)} stroke="var(--line)" strokeDasharray="2 4" />
            <text x={PAD.l - 8} y={toY(t) + 3} textAnchor="end" fill="var(--text-faint)" fontSize="10" fontFamily="JetBrains Mono, monospace">
              ${t.toFixed(0)}
            </text>
          </g>
        ))}

        {variant === 'gradient' && <path d={area} fill="url(#pch)" />}
        <path d={path} stroke="var(--accent)" strokeWidth="1.8" fill="none" strokeLinejoin="round" strokeLinecap="round" />

        {/* x-axis labels */}
        {[0, 0.25, 0.5, 0.75, 1].map((p, i) => {
          const idx = Math.floor(p * (data.length - 1));
          const x = toX(idx);
          return <text key={i} x={x} y={H - 10} textAnchor="middle" fill="var(--text-faint)" fontSize="10" fontFamily="JetBrains Mono, monospace">
            d{idx}
          </text>;
        })}

        {hover != null && (
          <g>
            <line x1={toX(hover)} x2={toX(hover)} y1={PAD.t} y2={H - PAD.b} stroke="var(--text-dim)" strokeDasharray="3 3"/>
            <circle cx={toX(hover)} cy={toY(data[hover])} r="4" fill="var(--accent)" stroke="var(--bg)" strokeWidth="2"/>
          </g>
        )}
      </svg>
      {hover != null && (
        <div style={{
          position: 'absolute',
          left: `calc(${(toX(hover) / W) * 100}% + 8px)`,
          top: `${(toY(data[hover]) / H) * 100}%`,
          transform: 'translateY(-100%)',
          background: 'var(--bg-3)', border: '1px solid var(--line-2)',
          padding: '6px 10px', borderRadius: 6, fontSize: 12,
          fontFamily: 'JetBrains Mono, monospace', pointerEvents: 'none', whiteSpace: 'nowrap',
        }}>
          <div style={{ color: 'var(--text-dim)', fontSize: 10 }}>day {hover}</div>
          <div style={{ color: 'var(--accent)', fontWeight: 500 }}>${data[hover].toFixed(2)}</div>
        </div>
      )}
    </div>
  );
}

function PriceHistory({ nav, params }) {
  const product = PRODUCTS.find(p => p.id === params.id) || PRODUCTS[0];
  const [range, setRange] = useState('3M');
  const [q, setQ] = useState(product.name);
  const [showSearch, setShowSearch] = useState(false);

  const data = HISTORY[range];
  const current = data[data.length - 1];
  const low = Math.min(...data);
  const high = Math.max(...data);
  const avg = data.reduce((a, b) => a + b, 0) / data.length;
  const tweaks = window.__TWEAKS__;

  const suggestions = PRODUCTS.filter(p => p.name.toLowerCase().includes(q.toLowerCase())).slice(0, 6);

  return (
    <div className="page fade-up">
      <div className="container ph-layout">
        <div>
          {/* Search */}
          <div className="search" style={{ marginBottom: 20, position: 'relative' }}>
            <Icon name="search" size={16}/>
            <input className="input" value={q} onFocus={() => setShowSearch(true)} onBlur={() => setTimeout(() => setShowSearch(false), 150)} onChange={e => { setQ(e.target.value); setShowSearch(true); }}
              placeholder="Search a product to see its price history…"/>
            {showSearch && suggestions.length > 0 && (
              <div className="card" style={{ position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0, zIndex: 10, padding: 6 }}>
                {suggestions.map(s => (
                  <button key={s.id} className="btn quiet" style={{ width: '100%', justifyContent: 'flex-start', padding: '8px 10px' }}
                    onMouseDown={() => { nav('/history?id=' + s.id); setQ(s.name); setShowSearch(false); }}>
                    <span className="mono" style={{ fontSize: 11, color: 'var(--text-faint)', marginRight: 10 }}>{s.brand.slice(0, 3).toUpperCase()}</span>
                    <span>{s.name}</span>
                    <span style={{ marginLeft: 'auto', color: 'var(--accent)', fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>${s.cheapest.toFixed(2)}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="card ph-main">
            <div className="hd">
              <div>
                <div className="mono" style={{ fontSize: 11, letterSpacing: '.1em', color: 'var(--text-faint)', textTransform: 'uppercase' }}>{product.brand} · {product.size}</div>
                <h2 className="serif" style={{ fontSize: 32, margin: '6px 0 0', letterSpacing: '-0.02em', fontWeight: 400 }}>{product.name.replace(product.brand, '').trim()}</h2>
              </div>
              <div className="range-tabs">
                {['7D', '1M', '3M', '6M', '1Y'].map(r => (
                  <button key={r} aria-pressed={range === r} onClick={() => setRange(r)}>{r}</button>
                ))}
              </div>
            </div>
            <div className="chart-wrap">
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginBottom: 14 }}>
                <span className="serif" style={{ fontSize: 48, letterSpacing: '-0.02em', lineHeight: 1 }}>${current.toFixed(2)}</span>
                <span className="pill success">
                  <Icon name="arrow-down" size={10}/>
                  {(((current - data[0]) / data[0]) * 100).toFixed(1)}% this period
                </span>
                <span className="mono" style={{ color: 'var(--text-faint)', fontSize: 12, marginLeft: 'auto' }}>
                  Lowest: ${low.toFixed(2)} · Highest: ${high.toFixed(2)}
                </span>
              </div>
              <PriceChart data={data} variant={tweaks.chartVariant}/>
            </div>
            <div className="ph-stats">
              <div className="stat2"><div className="lbl">Current</div><div className="num">${current.toFixed(2)}</div></div>
              <div className="stat2"><div className="lbl">90-day low</div><div className="num" style={{ color: 'var(--success)' }}>${low.toFixed(2)}</div></div>
              <div className="stat2"><div className="lbl">90-day avg</div><div className="num">${avg.toFixed(2)}</div></div>
              <div className="stat2"><div className="lbl">90-day high</div><div className="num">${high.toFixed(2)}</div></div>
            </div>
          </div>
        </div>

        {/* Right rail — price events */}
        <aside style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="card">
            <div style={{ padding: '18px 18px 14px', borderBottom: '1px solid var(--line)' }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Price events</div>
              <div style={{ fontSize: 12, color: 'var(--text-dim)', marginTop: 3 }}>Scraped changes across {product.storesCount} stores</div>
            </div>
            {PRICE_EVENTS.map((e, i) => (
              <div key={i} className="event-item">
                <div className="date">{e.date}</div>
                <div className="body">
                  <div><b>{e.title}</b></div>
                  <div style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: 2 }}>{e.detail}</div>
                </div>
                {e.delta !== 0 && (
                  <div className={'delta ' + e.dir}>
                    {e.dir === 'down' ? '↓' : '↑'} ${Math.abs(e.delta).toFixed(2)}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="card" style={{ padding: 18 }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Set a target price</div>
            <p style={{ color: 'var(--text-dim)', fontSize: 13, margin: '6px 0 14px' }}>We'll alert you the second any store drops below it.</p>
            <a href={'#/watchlist?add=' + product.id} className="btn primary" style={{ width: '100%', justifyContent: 'center' }}>
              <Icon name="bell" size={14}/> Add to watchlist
            </a>
          </div>
        </aside>
      </div>
    </div>
  );
}
window.PriceHistory = PriceHistory;
