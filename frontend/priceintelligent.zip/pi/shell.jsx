// App shell: header, router, tweaks panel
const { useState, useEffect, useRef, useMemo, useCallback } = React;

// --- Router ---
function useHashRoute() {
  const parse = () => {
    const h = window.location.hash || '#/';
    const [path, query = ''] = h.slice(1).split('?');
    const params = Object.fromEntries(new URLSearchParams(query));
    return { path, params };
  };
  const [route, setRoute] = useState(parse);
  useEffect(() => {
    const on = () => setRoute(parse());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  const nav = useCallback((to) => {
    window.location.hash = to.startsWith('#') ? to : '#' + to;
    window.scrollTo(0, 0);
  }, []);
  return { ...route, nav };
}
window.useHashRoute = useHashRoute;

// --- Header ---
function Header({ route, nav }) {
  const tabs = [
    { to: '/', label: 'Home', match: (p) => p === '/' || p === '' },
    { to: '/catalogue', label: 'Catalogue', match: (p) => p.startsWith('/catalogue') },
    { to: '/history', label: 'Price history', match: (p) => p.startsWith('/history') },
    { to: '/compare', label: 'Compare', match: (p) => p.startsWith('/compare') },
    { to: '/watchlist', label: 'Watchlist', match: (p) => p.startsWith('/watchlist') },
  ];
  return (
    <header className="header">
      <a href="#/" className="brand">
        <span className="brand-mark" aria-hidden />
        <span className="brand-name">Price<em>Intelligent</em></span>
      </a>
      <nav className="nav">
        {tabs.map(t => (
          <a key={t.to} href={'#' + t.to} className={t.match(route.path) ? 'active' : ''}>{t.label}</a>
        ))}
      </nav>
      <div className="header-right">
        <button className="btn quiet" title="Notifications"><Icon name="bell" size={16} /></button>
        <a className="btn ghost" href="#/signin">Sign in</a>
        <a className="btn primary" href="#/signup">Get started</a>
      </div>
    </header>
  );
}
window.Header = Header;

// --- Global Search Bar (below header) ---
function GlobalSearch({ nav }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        inputRef.current && inputRef.current.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const suggestions = q.trim()
    ? PRODUCTS.filter(p => (p.name + ' ' + p.brand + ' ' + p.category).toLowerCase().includes(q.toLowerCase())).slice(0, 6)
    : [];

  const go = (id) => {
    nav('/history?id=' + id);
    setQ(''); setOpen(false);
  };

  return (
    <div className="global-search-wrap">
      <div className="container">
        <div className="global-search" onFocus={() => setOpen(true)} onBlur={() => setTimeout(() => setOpen(false), 160)}>
          <Icon name="search" size={20}/>
          <input
            ref={inputRef}
            className="gs-input"
            placeholder="Search running shoes, GPS watches, gloves, rackets…"
            value={q}
            onChange={e => { setQ(e.target.value); setOpen(true); }}
            onKeyDown={e => { if (e.key === 'Enter' && suggestions[0]) go(suggestions[0].id); }}
          />
          <span className="gs-kbd"><span className="kbd">⌘K</span></span>
          <button className="btn primary gs-btn" onClick={() => nav('/catalogue')}>
            Browse all <Icon name="arrow-r" size={14}/>
          </button>
          {open && suggestions.length > 0 && (
            <div className="gs-dropdown">
              <div className="gs-dropdown-hd">
                <span>Products</span>
                <span className="mono">{suggestions.length} match{suggestions.length === 1 ? '' : 'es'}</span>
              </div>
              {suggestions.map(s => (
                <button key={s.id} className="gs-row" onMouseDown={() => go(s.id)}>
                  <span className="gs-row-thumb" style={{ background: `linear-gradient(155deg, ${s.bucketColor}, color-mix(in oklab, ${s.bucketColor} 60%, #000))` }}/>
                  <div className="gs-row-body">
                    <div className="gs-row-name">{s.name}</div>
                    <div className="gs-row-sub">{s.brand} · {s.category} · {s.size}</div>
                  </div>
                  <div className="gs-row-price mono">${s.cheapest.toFixed(2)}</div>
                </button>
              ))}
              <div className="gs-dropdown-ft">
                <span>Press <span className="kbd">Enter</span> to open price history</span>
                <a href="#/catalogue" onMouseDown={(e) => { e.preventDefault(); nav('/catalogue'); }}>See all {PRODUCTS.length} products →</a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
window.GlobalSearch = GlobalSearch;

// --- Footer ---
function Footer() {
  return (
    <footer className="footer">
      <div>© 2026 PriceIntelligent — Sports price intelligence</div>
      <div className="mono">tracking 428 stores · updated every 15 min</div>
    </footer>
  );
}
window.Footer = Footer;

// --- Tweaks Panel ---
function useTweaks() {
  const [t, setT] = useState(window.__TWEAKS__);
  useEffect(() => {
    document.documentElement.setAttribute('data-accent', t.accent);
    document.documentElement.setAttribute('data-mode', t.mode);
    document.documentElement.setAttribute('data-density', t.density);
    document.documentElement.setAttribute('data-chart-variant', t.chartVariant);
    document.documentElement.setAttribute('data-card-variant', t.cardVariant);
    window.__TWEAKS__ = t;
    try { localStorage.setItem('pi_tweaks', JSON.stringify(t)); } catch(e) {}
  }, [t]);
  const update = (patch) => {
    setT(prev => {
      const next = { ...prev, ...patch };
      try {
        window.parent.postMessage({ type: '__edit_mode_set_keys', edits: patch }, '*');
      } catch(e) {}
      return next;
    });
  };
  return [t, update];
}
window.useTweaks = useTweaks;

function TweaksPanel({ tweaks, setTweaks, onClose }) {
  const accents = [
    { id: 'lime', color: '#c8ff2c' },
    { id: 'cyan', color: '#5ef0ff' },
    { id: 'orange', color: '#ff9544' },
    { id: 'violet', color: '#b48cff' },
  ];
  return (
    <div className="tweaks-panel">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
        <h4>Tweaks</h4>
        <button className="btn quiet sm" onClick={onClose}><Icon name="x" size={14} /></button>
      </div>
      <div className="tweaks-row">
        <span>Accent</span>
        <div className="swatches">
          {accents.map(a => (
            <button key={a.id} className="swatch" aria-selected={tweaks.accent === a.id}
              style={{ background: a.color, color: a.color }}
              onClick={() => setTweaks({ accent: a.id })} aria-label={a.id} />
          ))}
        </div>
      </div>
      <div className="tweaks-row">
        <span>Mode</span>
        <div className="seg">
          <button aria-pressed={tweaks.mode === 'dark'} onClick={() => setTweaks({ mode: 'dark' })}>Dark</button>
          <button aria-pressed={tweaks.mode === 'light'} onClick={() => setTweaks({ mode: 'light' })}>Light</button>
        </div>
      </div>
      <div className="tweaks-row">
        <span>Density</span>
        <div className="seg">
          <button aria-pressed={tweaks.density === 'comfy'} onClick={() => setTweaks({ density: 'comfy' })}>Comfy</button>
          <button aria-pressed={tweaks.density === 'compact'} onClick={() => setTweaks({ density: 'compact' })}>Compact</button>
        </div>
      </div>
      <div className="tweaks-row">
        <span>Chart</span>
        <div className="seg">
          <button aria-pressed={tweaks.chartVariant === 'gradient'} onClick={() => setTweaks({ chartVariant: 'gradient' })}>Gradient</button>
          <button aria-pressed={tweaks.chartVariant === 'line'} onClick={() => setTweaks({ chartVariant: 'line' })}>Line</button>
          <button aria-pressed={tweaks.chartVariant === 'stepped'} onClick={() => setTweaks({ chartVariant: 'stepped' })}>Steps</button>
        </div>
      </div>
      <div className="tweaks-row">
        <span>Cards</span>
        <div className="seg">
          <button aria-pressed={tweaks.cardVariant === 'detailed'} onClick={() => setTweaks({ cardVariant: 'detailed' })}>Detailed</button>
          <button aria-pressed={tweaks.cardVariant === 'minimal'} onClick={() => setTweaks({ cardVariant: 'minimal' })}>Minimal</button>
        </div>
      </div>
    </div>
  );
}
window.TweaksPanel = TweaksPanel;

function useEditMode() {
  const [on, setOn] = useState(false);
  useEffect(() => {
    const handler = (e) => {
      if (!e.data) return;
      if (e.data.type === '__activate_edit_mode') setOn(true);
      if (e.data.type === '__deactivate_edit_mode') setOn(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);
  return [on, setOn];
}
window.useEditMode = useEditMode;

// Bucket placeholder - used for product "images"
function Bucket({ color = '#2a3a1f', className }) {
  return <div className={'bucket ' + (className || '')} style={{ background: `linear-gradient(155deg, ${color}, color-mix(in oklab, ${color} 60%, #000))` }} />;
}
window.Bucket = Bucket;
