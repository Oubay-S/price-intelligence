// Fictional store names (to avoid recreating branded UI)
const STORES = [
  { id: 'peakmart',   name: 'PeakMart',      color: '#ff8a3d', short: 'P' },
  { id: 'ironworks',  name: 'IronWorks',     color: '#5ef0ff', short: 'I' },
  { id: 'supplyhub',  name: 'SupplyHub',     color: '#c8ff2c', short: 'S' },
  { id: 'vitacore',   name: 'Vitacore',      color: '#b48cff', short: 'V' },
  { id: 'swolestore', name: 'SwoleStore',    color: '#ff5b6b', short: 'W' },
  { id: 'dailyfuel',  name: 'DailyFuel',     color: '#2ee6a6', short: 'D' },
  { id: 'fieldco',    name: 'FieldCo',       color: '#7dd3fc', short: 'F' },
  { id: 'trackworld', name: 'TrackWorld',    color: '#facc15', short: 'T' },
];

// Category tree
const TAXONOMY = [
  {
    id: 'gym', name: 'Gym Products',
    subs: [
      { id: 'nutrition',   name: 'Nutrition' },
      { id: 'home-gym',    name: 'Home Gym' },
      { id: 'wearables',   name: 'Wearables' },
    ],
  },
  {
    id: 'team', name: 'Pitch & Court Sports',
    subs: [
      { id: 'football',    name: 'Football' },
      { id: 'basketball',  name: 'Basketball' },
      { id: 'volleyball',  name: 'Volleyball' },
      { id: 'racket',      name: 'Racket Sports' },
    ],
  },
  {
    id: 'endurance', name: 'Endurance & Athletics',
    subs: [
      { id: 'road-shoes',  name: 'Road Running Shoes' },
      { id: 'trail-shoes', name: 'Trail Shoes' },
      { id: 'spikes',      name: 'Track Spikes' },
      { id: 'gps-watch',   name: 'GPS Watches' },
      { id: 'hr-monitor',  name: 'Heart Rate Monitors' },
      { id: 'hydration',   name: 'Hydration Vests' },
      { id: 'gels',        name: 'Energy Gels' },
      { id: 'electrolytes',name: 'Electrolyte Tablets' },
    ],
  },
  {
    id: 'combat', name: 'Combat Sports',
    subs: [
      { id: 'bag-gloves',    name: 'Bag Gloves' },
      { id: 'spar-gloves',   name: 'Sparring Gloves' },
      { id: 'hand-wraps',    name: 'Hand Wraps' },
      { id: 'mouthguards',   name: 'Mouthguards' },
      { id: 'headgear',      name: 'Headgear' },
      { id: 'shin-guards',   name: 'Shin Protectors' },
      { id: 'groin-guards',  name: 'Groin Guards' },
    ],
  },
];

// Per-sub product templates: brands, product names, price bands, size strings
const SUB_DATA = {
  // ---- Gym ----
  'nutrition':   { brands: ['Optimum Core','RyseLab','Transparent Co.','NitroPeak','OneScoop','HydraMax'],
                   names: ['Gold Whey Isolate','Micronized Creatine','Thermal Surge Pre','BCAA 2:1:1','Mass Factor','Clear Whey'],
                   sizes: ['1 lb','2 lb','5 lb','30 svg'], base: [22, 78], hues: ['#2a3a1f','#3a2f1f','#2a1c40'] },
  'home-gym':    { brands: ['IronForge','KettleCo','BlackFlag','RackMaster'],
                   names: ['Adjustable Dumbbell','Olympic Barbell','Kettlebell Pro','Resistance Band Set','Weight Bench','Power Rack'],
                   sizes: ['20 kg','40 kg','pair','set'], base: [60, 480], hues: ['#2a2a2a','#1f1f2a','#302018'] },
  'wearables':   { brands: ['PulseTech','FitNode','CoreMetrics','BandLab'],
                   names: ['Fitness Tracker X','Smart Ring V2','Chest Strap HRM','Form Sensor Pod'],
                   sizes: ['S/M','L/XL','one size'], base: [45, 280], hues: ['#1f2a3a','#2a1c40','#1f3a2a'] },

  // ---- Team ----
  'football':    { brands: ['FieldKit','Stripe & Sole','GoalWear','Azzurri Co.'],
                   names: ['Match Cleats FG','Turf Trainer','Training Ball','Shinpad Pro','Goalkeeper Glove'],
                   sizes: ['US 8','US 9','US 10','US 11','size 5'], base: [28, 240], hues: ['#1f3a2a','#2a1c40','#3a1f2a'] },
  'basketball':  { brands: ['HoopLab','AirPoint','Court Co.','RimRider'],
                   names: ['High-Top Court Shoe','Indoor Basketball','Arm Sleeve','Ankle Brace'],
                   sizes: ['US 9','US 10','US 11','US 12','size 7'], base: [22, 180], hues: ['#3a1f2a','#2a2a2a','#3a2f1f'] },
  'volleyball':  { brands: ['SpikeCo','NetWorks','LiberoKit'],
                   names: ['Volleyball Shoe','Knee Pad Pro','Indoor Volleyball','Libero Jersey'],
                   sizes: ['US 8','US 9','US 10','size 5'], base: [18, 140], hues: ['#1f2a3a','#2a1c40'] },
  'racket':      { brands: ['StringTheory','SwingCo','AceLab','Padel Pro'],
                   names: ['Tennis Racket 300g','Padel Racket Pro','Badminton Racket','Squash Racket','String Reel'],
                   sizes: ['grip 2','grip 3','100 sq.in','200m'], base: [45, 320], hues: ['#2a3a1f','#3a2f1f','#1f3a2a'] },

  // ---- Endurance ----
  'road-shoes':  { brands: ['Pacer','Strider','FormLab','AeroRun'],
                   names: ['Carbon Plate Racer','Daily Trainer','Tempo Trainer','Supershoe v4'],
                   sizes: ['US 8','US 9','US 10','US 11','US 12'], base: [90, 280], hues: ['#1f2a3a','#2a1c40','#3a1f2a'] },
  'trail-shoes': { brands: ['RidgeLine','Scree Co.','MudLab'],
                   names: ['Mountain Trail GTX','Ultra Trail 100','Fell Runner Pro'],
                   sizes: ['US 9','US 10','US 11','US 12'], base: [110, 240], hues: ['#3a2f1f','#1f3a2a','#2a2a2a'] },
  'spikes':      { brands: ['TrackCo','Stride','SprintLab'],
                   names: ['Mid-D Spike','Sprint Spike 100','Distance Spike'],
                   sizes: ['US 8','US 9','US 10'], base: [70, 180], hues: ['#2a1c40','#3a1f2a'] },
  'gps-watch':   { brands: ['Garmont','Suvic','FenxTech','PaceOS'],
                   names: ['Fenix Trail GPS','Runner Elite 2','Multisport Pro','Solar Explorer'],
                   sizes: ['42mm','46mm','51mm'], base: [180, 1100], hues: ['#1f2a3a','#2a2a2a','#1f3a2a'] },
  'hr-monitor':  { brands: ['PulseTech','CoreMetrics','BeatLab'],
                   names: ['Chest Strap Gen3','Arm HR Monitor','Optical Sensor Pod'],
                   sizes: ['S/M','L/XL','one size'], base: [45, 160], hues: ['#3a1f2a','#2a1c40'] },
  'hydration':   { brands: ['HydraVest','PackLab','Salomont'],
                   names: ['Trail Vest 12L','Race Vest 5L','Ultra Pack 20L'],
                   sizes: ['XS','S','M','L'], base: [70, 260], hues: ['#1f3a2a','#2a3a1f'] },
  'gels':        { brands: ['FuelCo','GlyCo','Maurice'],
                   names: ['Energy Gel Caffeine','Endurance Gel Box','Isotonic Gel Pack'],
                   sizes: ['12 pack','24 pack','single'], base: [14, 70], hues: ['#3a2f1f','#2a3a1f'] },
  'electrolytes':{ brands: ['SaltLab','NuuTab','Precision Co.'],
                   names: ['Electrolyte Tabs','Salt Caps 100ct','Hydration Sticks'],
                   sizes: ['10 tabs','20 tabs','30 pack'], base: [10, 45], hues: ['#2a1c40','#1f2a3a'] },

  // ---- Combat ----
  'bag-gloves':  { brands: ['IronFist','Reyas','Winlabs','Ring Co.'],
                   names: ['Bag Glove 16oz','Heavy Bag 14oz','Velcro Bag Glove'],
                   sizes: ['12 oz','14 oz','16 oz'], base: [55, 220], hues: ['#3a1f2a','#2a2a2a'] },
  'spar-gloves': { brands: ['Reyas','Winlabs','Top Kingz','Ring Co.'],
                   names: ['Sparring Glove 16oz','Pro Spar Glove','Lace-up Sparring'],
                   sizes: ['14 oz','16 oz','18 oz'], base: [90, 320], hues: ['#2a1c40','#3a2f1f'] },
  'hand-wraps':  { brands: ['WrapCo','IronFist','Ring Co.'],
                   names: ['Mexican Wraps 180"','Gel Knuckle Wraps','Quick Wrap'],
                   sizes: ['180"','120"','one size'], base: [9, 35], hues: ['#3a2f1f','#1f2a3a'] },
  'mouthguards': { brands: ['ShockDoc','BiteLab','GuardCo'],
                   names: ['Pro Mouthguard','Custom Boil Guard','Double Mouthguard'],
                   sizes: ['youth','adult'], base: [15, 60], hues: ['#2a1c40','#1f3a2a'] },
  'headgear':    { brands: ['Reyas','Winlabs','Top Kingz'],
                   names: ['Competition Headgear','Full-Face Sparring HG','Open-Face HG'],
                   sizes: ['M','L','XL'], base: [80, 280], hues: ['#3a1f2a','#2a2a2a'] },
  'shin-guards': { brands: ['ShinLab','Top Kingz','IronFist'],
                   names: ['Muay Thai Shin Guard','Kickboxing Shin Pad','Leather Shin Pro'],
                   sizes: ['M','L','XL'], base: [55, 210], hues: ['#2a1c40','#3a2f1f'] },
  'groin-guards':{ brands: ['GuardCo','IronFist','Reyas'],
                   names: ['Steel Cup Groin Guard','Foul Protector','Reinforced Cup'],
                   sizes: ['M','L'], base: [35, 140], hues: ['#1f3a2a','#3a1f2a'] },
};

// flat list
const CATEGORIES = TAXONOMY.map(c => c.name);
const SUBS = TAXONOMY.flatMap(c => c.subs.map(s => ({ ...s, categoryId: c.id, categoryName: c.name })));
const ALL_BRANDS = [...new Set(Object.values(SUB_DATA).flatMap(d => d.brands))].sort();

function seeded(seed) {
  let s = seed;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

function makeProduct(i, subKey, topCat) {
  const sub = SUBS.find(s => s.id === subKey);
  const template = SUB_DATA[subKey];
  const r = seeded(i * 77 + 3);
  const brand = template.brands[Math.floor(r() * template.brands.length)];
  const baseName = template.names[Math.floor(r() * template.names.length)];
  const sizeStr = template.sizes[Math.floor(r() * template.sizes.length)];
  const [lo, hi] = template.base;
  const priceBase = lo + Math.floor(r() * (hi - lo));

  const prices = STORES.map((s) => ({
    store: s.id,
    price: +(priceBase + (r() - 0.5) * priceBase * 0.2).toFixed(2),
    shipping: r() > 0.55 ? 0 : +(3.99 + r() * 8).toFixed(2),
    stock: r() > 0.15,
    rating: +(3.8 + r() * 1.2).toFixed(1),
    delivery: Math.ceil(1 + r() * 4) + '–' + Math.ceil(3 + r() * 6) + ' days',
  }));
  const cheapest = prices.reduce((a, b) => a.price < b.price ? a : b);
  const rrp = +(Math.max(...prices.map(p => p.price)) * (1 + r() * 0.15)).toFixed(2);
  const hue = template.hues[Math.floor(r() * template.hues.length)];

  return {
    id: 'p' + i,
    name: `${brand} ${baseName}`,
    brand,
    category: topCat.name,
    categoryId: topCat.id,
    sub: sub.name,
    subId: sub.id,
    flavor: sizeStr,       // keep field name for compat
    size: sizeStr,
    rating: +(3.9 + r() * 1.1).toFixed(1),
    reviews: Math.floor(120 + r() * 3400),
    prices,
    cheapest: cheapest.price,
    cheapestStore: cheapest.store,
    rrp,
    savePct: Math.round(((rrp - cheapest.price) / rrp) * 100),
    bucketColor: hue,
    storesCount: prices.filter(p => p.stock).length,
    tags: [sub.name, r() > 0.5 ? 'Best seller' : null, r() > 0.75 ? 'New' : null].filter(Boolean),
    priceBase,
  };
}

// Spread products across sub-categories — ensures coverage in each
const PRODUCTS = [];
let counter = 1;
TAXONOMY.forEach(topCat => {
  topCat.subs.forEach(sub => {
    const n = 2; // 2 per sub
    for (let k = 0; k < n; k++) {
      PRODUCTS.push(makeProduct(counter++, sub.id, topCat));
    }
  });
});

// BRANDS: backwards compat
const BRANDS = ALL_BRANDS;

// Price history for the first product
function genHistory(seed, days, base) {
  const r = seeded(seed);
  const arr = [];
  let p = base;
  for (let i = 0; i < days; i++) {
    const wobble = (r() - 0.5) * 2.2;
    const drift = Math.sin(i / (days / 6)) * 1.2;
    p = Math.max(base * 0.78, Math.min(base * 1.12, p + wobble * 0.4 + drift * 0.08));
    if (r() > 0.97) p = p * 0.9;
    arr.push(+p.toFixed(2));
  }
  return arr;
}

const HIST_BASE = PRODUCTS[0].priceBase || 48;
const HISTORY = {
  '7D':  genHistory(11, 7,  HIST_BASE),
  '1M':  genHistory(11, 30, HIST_BASE),
  '3M':  genHistory(11, 90, HIST_BASE),
  '6M':  genHistory(11, 180, HIST_BASE),
  '1Y':  genHistory(11, 365, HIST_BASE),
};

const PRICE_EVENTS = [
  { date: 'Apr 18', title: 'PeakMart dropped price', detail: 'Spring sale — 12% off', delta: -5.80, dir: 'down' },
  { date: 'Apr 09', title: 'IronWorks went out of stock', detail: 'Back in stock expected Apr 24', delta: 0, dir: 'flat' },
  { date: 'Mar 28', title: 'SupplyHub raised price', detail: 'Shipping surcharge added', delta: +2.40, dir: 'up' },
  { date: 'Mar 14', title: 'Vitacore new low', detail: 'Lowest price in 90 days', delta: -3.10, dir: 'down' },
  { date: 'Feb 22', title: 'FieldCo listed product', detail: 'New store tracking this item', delta: 0, dir: 'flat' },
];

const WATCHLIST = [
  { productId: PRODUCTS[0].id, currentPrice: PRODUCTS[0].cheapest, target: +(PRODUCTS[0].cheapest * 0.88).toFixed(2), alerts: ['email','push'] },
  { productId: PRODUCTS[4].id, currentPrice: PRODUCTS[4].cheapest, target: +(PRODUCTS[4].cheapest * 0.85).toFixed(2), alerts: ['email'] },
  { productId: PRODUCTS[10].id, currentPrice: PRODUCTS[10].cheapest, target: +(PRODUCTS[10].cheapest * 0.9).toFixed(2), alerts: ['push'] },
  { productId: PRODUCTS[18].id, currentPrice: PRODUCTS[18].cheapest, target: +(PRODUCTS[18].cheapest * 0.8).toFixed(2), alerts: ['email'] },
];

window.STORES = STORES;
window.TAXONOMY = TAXONOMY;
window.SUBS = SUBS;
window.BRANDS = BRANDS;
window.CATEGORIES = CATEGORIES;
window.PRODUCTS = PRODUCTS;
window.HISTORY = HISTORY;
window.PRICE_EVENTS = PRICE_EVENTS;
window.WATCHLIST = WATCHLIST;
