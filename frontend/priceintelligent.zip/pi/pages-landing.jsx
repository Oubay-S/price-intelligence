// Landing page with animated stat counters
function useAnimatedNumber(target, duration = 1600) {
  const [v, setV] = useState(0);
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const t0 = performance.now();
    let raf;
    const tick = (now) => {
      const p = Math.min(1, (now - t0) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setV(target * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return v;
}

function Stat({ value, suffix = '', prefix = '', label, decimals = 0 }) {
  const n = useAnimatedNumber(value);
  const formatted = n.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return (
    <div className="stat">
      <div className="num">{prefix}<em>{formatted}</em>{suffix}</div>
      <div className="lbl">{label}</div>
    </div>
  );
}

function MiniChart() {
  const pts = HISTORY['3M'].slice(-60);
  const min = Math.min(...pts), max = Math.max(...pts);
  const W = 520, H = 180, P = 8;
  const toXY = (i) => [P + (i / (pts.length - 1)) * (W - 2*P), H - P - ((pts[i] - min) / (max - min)) * (H - 2*P)];
  const path = pts.map((_, i) => { const [x, y] = toXY(i); return (i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); }).join(' ');
  const area = path + ` L ${W - P} ${H - P} L ${P} ${H - P} Z`;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" preserveAspectRatio="none" style={{ display: 'block' }}>
      <defs>
        <linearGradient id="lg" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.35"/>
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={area} fill="url(#lg)" />
      <path d={path} stroke="var(--accent)" strokeWidth="1.8" fill="none" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function HeroCollage() {
  const tiles = [
    { cls: 'htile-shoe',  label: 'Running · −22%', dot: 'var(--success)', price: '142.80',
      img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80' },
    { cls: 'htile-watch', label: 'GPS Watch',      dot: 'var(--accent)',  price: '489.00',
      img: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=500&q=80' },
    { cls: 'htile-glove', label: 'Combat · 16oz',  dot: '#ff5b6b',        price: '78.50',
      img: 'https://images.unsplash.com/photo-1593351415075-3bac9f45c877?w=500&q=80' },
    { cls: 'htile-tub',   label: 'Nutrition · 5lb', dot: 'var(--success)', price: '42.80',
      img: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500&q=80' },
    { cls: 'htile-ball',  label: 'Team · size 5',  dot: '#7dd3fc',        price: '24.99',
      img: 'https://images.unsplash.com/photo-1614632537190-23e4b2e69c88?w=500&q=80' },
  ];
  return (
    <div className="hero-collage">
      {tiles.map(t => (
        <div key={t.cls} className={'htile ' + t.cls}>
          <img src={t.img} alt="" className="htile-img" loading="lazy"/>
          <div className="htile-grad"/>
          <div className="htile-label"><span className="dot" style={{background: t.dot}}/>{t.label}</div>
          <div className="htile-price">${t.price.split('.')[0]}<span>.{t.price.split('.')[1]}</span></div>
        </div>
      ))}
      <div className="hero-live">
        <span className="dot" style={{background:'var(--accent)', boxShadow:'0 0 0 3px var(--accent-glow)'}}/>
        <span className="mono">PRICE DROPPED · 3s AGO</span>
      </div>
    </div>
  );
}

function Landing({ nav }) {
  return (
    <div className="page fade-up">
      <section className="hero">
        <div className="hero-grid"/>
        <div className="hero-bg"/>
        <div className="container" style={{ position: 'relative' }}>
          <div className="hero-split">
            <div>
              <span className="eyebrow"><span className="dot"/> Live — tracking 428 sports retailers</span>
              <h1>Never pay full price<br/>on your <span className="mark">gear</span> again.</h1>
              <p className="lede">PriceIntelligent scrapes every major sports retailer in real time — gym, team sports, running, combat. Find the lowest price on any product and get alerted the moment it drops.</p>
              <div style={{ display: 'flex', gap: 10, marginBottom: 56 }}>
                <a className="btn primary lg" href="#/catalogue">Browse catalogue <Icon name="arrow-r" size={16}/></a>
                <a className="btn ghost lg" href="#/history">See a live price graph</a>
              </div>
            </div>
            <HeroCollage/>
          </div>

          <div className="stats-row">
            <Stat value={184293} label="Prices tracked" />
            <Stat value={428} label="Stores scraped" />
            <Stat value={2.4} suffix="M" label="Saved by users" prefix="$" decimals={1} />
            <Stat value={15} suffix=" min" label="Refresh interval" />
          </div>
        </div>
      </section>

      <section className="container" style={{ marginTop: 20 }}>
        <div className="preview">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 10px 10px' }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span className="pill"><span className="dot" style={{ background: 'var(--success)' }}/> Pacer Carbon Plate Racer</span>
              <span className="pill accent">Lowest $182.40 at PeakMart</span>
            </div>
            <span className="mono" style={{ fontSize: 11, color: 'var(--text-faint)' }}>90D · updated 2m ago</span>
          </div>
          <div className="preview-inner" style={{ padding: '20px 20px 4px' }}>
            <MiniChart/>
          </div>
        </div>
      </section>

      <section className="container">
        <div className="features">
          <div className="feature card">
            <div className="icon"><Icon name="chart" size={18}/></div>
            <h3>Price history that matters</h3>
            <p>90 days of scraped price data per SKU — see the real floor, not just today's deal of the day.</p>
          </div>
          <div className="feature card">
            <div className="icon"><Icon name="compare" size={18}/></div>
            <h3>Side-by-side comparison</h3>
            <p>One table, every store. Shipping, stock, delivery window — all normalized so you can pick the actual best offer.</p>
          </div>
          <div className="feature card">
            <div className="icon"><Icon name="bell" size={18}/></div>
            <h3>Threshold alerts</h3>
            <p>Drop a target price on anything in your watchlist. We'll ping you the second any tracked store goes below it.</p>
          </div>
          <div className="feature card">
            <div className="icon"><Icon name="globe" size={18}/></div>
            <h3>Every store, one place</h3>
            <p>From big-box marketplaces to niche sports specialists — if they sell it, we're watching.</p>
          </div>
          <div className="feature card">
            <div className="icon"><Icon name="zap" size={18}/></div>
            <h3>15-minute refresh</h3>
            <p>Not a nightly batch. Prices are rechecked every 15 minutes on hot items, four hours on the long tail.</p>
          </div>
          <div className="feature card">
            <div className="icon"><Icon name="shield" size={18}/></div>
            <h3>No affiliate bias</h3>
            <p>We show the cheapest price. Full stop. No reordered tables or sponsored stores.</p>
          </div>
        </div>
      </section>

      <section className="container" style={{ paddingBottom: 100 }}>
        <div className="card elev" style={{ padding: 48, display: 'grid', gridTemplateColumns: '1fr auto', alignItems: 'center', gap: 24 }}>
          <div>
            <h2 className="serif" style={{ fontSize: 44, margin: 0, letterSpacing: '-0.02em', lineHeight: 1 }}>
              Start tracking in <span style={{ color: 'var(--accent)', fontStyle: 'italic' }}>under a minute.</span>
            </h2>
            <p style={{ color: 'var(--text-dim)', margin: '12px 0 0', maxWidth: 520 }}>
              Free forever — no credit card, no store accounts. Just paste a product URL or search, and we'll do the rest.
            </p>
          </div>
          <a className="btn primary lg" href="#/signup">Create free account <Icon name="arrow-r" size={16}/></a>
        </div>
      </section>
    </div>
  );
}
window.Landing = Landing;
